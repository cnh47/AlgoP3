#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

class SCImage
{
    private:
        int** image;
        int** peMatrix;
        int w;
        int h;
        string maxGreyScale;


    public:
        SCImage(string);
        void sC(int,int);
        void outputCarvImage(string);

    private:
        void collectFromFile(string);
        void genPixEnerMatrix();
        int calcPixEner(int,int);
        void vCarve();
        void hCarve();
        void idVSeam();
        void deleteVSeam();
        void rotateImage();


};

SCImage::SCImage(string fileName)
{
    collectFromFile(fileName);
    peMatrix = NULL;
    genPixEnerMatrix();
}

void SCImage::collectFromFile(string imageName)
{

        ifstream inFile;
        inFile.open(imageName);

        string processInFile;
        int stepCount = 1;
        vector<string> cArray;

        while (getline(inFile, processInFile))
        {
            if (processInFile[0]=='#')
            {

            }
            else if (stepCount == 1)
            {

                stepCount++;
            }
            else if (stepCount == 2)
            {

                int space = processInFile.find(" ");
                string xStr = processInFile.substr(0,space);
                string yStr = processInFile.substr(space + 1);
                w = atoi(xStr.c_str());
                h = atoi(yStr.c_str());

                image = new int*[w];
                for(int i = 0; i < w; i++)
                    image[i] = new int[h];

                stepCount++;
            }
            else if(stepCount == 3)
            {
                maxGreyScale = processInFile;
                stepCount++;
            }
            else
            {
                string numString = "";
                int strLen = processInFile.length();
                for (int i = 0; i < strLen; i++)
                {
                    if(processInFile[i] == ' ' || processInFile[i] == '\t' || processInFile[i] == '\n')
                    {
                        cArray.push_back(numString);
                        numString = "";
                    }
                    else
                    {
                        numString += processInFile[i];
                    }
                }

                if (numString != "")
                    cArray.push_back(numString);

            }

        }

        inFile.close();
        int vectorIterator = 0;
        for (int y = 0; y < h; y++)
        {
            for(int x = 0; x < w; x++)
            {
                string curIter = cArray.at(vectorIterator);
                image[x][y] = atoi(curIter.c_str());
                vectorIterator++;
            }
        }
}

void SCImage::outputCarvImage(string fileName)
{
    ofstream outFile(fileName + "_processed.pgm");
    outFile << "P2" << endl << w << " " << h << endl << maxGreyScale << endl;

    for (int y = 0; y < h; y++)
    {
        for(int x = 0; x < w; x++)
        {
            outFile<< image[x][y] << " ";
        }
        outFile << endl;
    }
    outFile.close();
}

void SCImage::genPixEnerMatrix()
{
    if (peMatrix != NULL)
    {
        for (int i = 0; i < w -1; i++)
            delete [] peMatrix[i];

        delete [] peMatrix;
    }
    peMatrix = new int*[w];
    for (int i = 0; i < w; i++)
        peMatrix[i] = new int[h];

    for (int y =0; y < h; y++)
    {
        for (int x = 0; x<w; x++)
            peMatrix[x][y] = calcPixEner(x,y);
    }
}

int SCImage::calcPixEner(int x, int y)
{
    int currPix = image[x][y];
    int abovePix,belowPix,rightPix, leftPix;

    if (x==0)
        leftPix = image[x][y];
    else
        leftPix = image[x-1][y];

    if ( y ==0)
        belowPix = image[x][y];
    else
        belowPix = image[x][y-1];

    if (x == w - 1)
        rightPix = image[x][y];
    else
        rightPix = image[x+1][y];

    if (y == h-1)
        abovePix = image[x][y];
    else
        abovePix = image[x][y+1];

    return (abs(currPix-abovePix) + abs(currPix-belowPix) + abs(currPix-rightPix) + abs(currPix - leftPix));

}

void SCImage::sC(int vCarves, int hCarves)
{
    for ( int i = 0; i < vCarves; i++)
    {
        vCarve();
        genPixEnerMatrix();
    }
    for (int i = 0; i < hCarves; i++)
    {
        hCarve();
        genPixEnerMatrix();
    }
}


void SCImage::vCarve()
{
    idVSeam();
    deleteVSeam();
}

void SCImage::hCarve()
{
    rotateImage();
    vCarve();
    rotateImage();
}

void SCImage::idVSeam()
{
    int** cumEnergy = new int*[w];
    for(int i = 0; i < w; i++)
        cumEnergy[i] = new int[h];

    for (int y = 0; y<h; y++)
    {
        for (int x = 0; x < w; x++)
        {
            if (y==0)
            {
                cumEnergy[x][y] = peMatrix[x][y];
            }
            else
            {
                int minLast;
                if (x == 0)
                {
                    minLast = min(cumEnergy[x+1][y-1], cumEnergy[x][y-1]);
                }
                else if (x == (w-1))
                {
                    minLast = min(cumEnergy[x-1][y-1], cumEnergy[x][y-1]);
                }
                else
                {
                    minLast = min(min(cumEnergy[x-1][y-1], cumEnergy[x+1][y-1]),cumEnergy[x][y-1]);
                }
                cumEnergy[x][y] = peMatrix[x][y] + minLast;
            }
        }
    }


    int lowestIndex = 0;

    for (int i = 0; i < w; i++)
    {
        if(cumEnergy[i][h-1] < cumEnergy[lowestIndex][h-1])
            lowestIndex=i;
    }
    image[lowestIndex][h-1] = -1;

    for(int i = 1; i <h; i++)
    {
        int currentH = h -1 - i;
        int rIndex = lowestIndex + 1;
        int mIndex = lowestIndex;
        int lIndex = lowestIndex -1;

        if (rIndex <0 || rIndex >= w)
            rIndex = mIndex;
        if(lIndex < 0 || lIndex >= w)
            lIndex = mIndex;

        int lowestValue = min(min(cumEnergy[rIndex][currentH], cumEnergy[lIndex][currentH]),cumEnergy[mIndex][currentH]);
        if(cumEnergy[lIndex][currentH] == lowestValue)
            lowestIndex = lIndex;
        else if(cumEnergy[mIndex][currentH]== lowestValue)
            lowestIndex = mIndex;
        else if(cumEnergy[rIndex][currentH] == lowestValue)
            lowestIndex = rIndex;

        image[lowestIndex][currentH] = -1;

    }

}

void SCImage::deleteVSeam()
{
    int oldW = w;
    w--;
    vector<int> contArray;

    for (int y = 0; y <h; y++)
    {
        for (int x = 0; x < oldW; x++)
        {
            if (image[x][y]!= -1)
                contArray.push_back(image[x][y]);
        }
    }
    for (int i = 0; i < w; i++)
        delete [] image[i];

    delete [] image;
    image = new int*[w];
    for (int i = 0; i <w; i++)
    {
        image[i] = new int[h];
    }

    int vectIter = 0;
    for(int y = 0; y <h; y++)
    {
        for (int x = 0; x < w; x++)
        {
            image[x][y] = contArray.at(vectIter);
            vectIter++;
        }
    }
}

void SCImage::rotateImage()
{
    for (int i = 0; i <w; i++)
        delete [] peMatrix[i];

    delete [] peMatrix;
    peMatrix = NULL;

    int preRotateW = w;
    int preRotateH = h;

    h = preRotateW;
    w = preRotateH;

    int** oldImage = image;
    image = new int*[w];
    for(int i = 0; i<w; i++)
        image[i] = new int[h];

    for (int y = 0; y<h; y++)
    {
        for (int x = 0; x< w; x++)
        {
            image[x][y] = oldImage[y][x];
        }
    }

    genPixEnerMatrix();
    for(int i = 0; i < h; i++)
        delete [] oldImage[i];

    delete [] oldImage;

}
