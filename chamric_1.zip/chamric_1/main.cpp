#include "SCImage.h"

using namespace std;

int main(int argc, char*argv[])
{

    if (argc < 3)
        cout<< "wrong format! should be \"a.exe HorizontalSeamsToRemove VerticalSeamsToRemove imageToProcess\"";
    else
    {
        int toRemoveVerticalSeam = atoi(argv[2]);
        int toRemoveHorizontalSeam = atoi(argv[3]);
        string dataFile = argv[1];

        SCImage image(dataFile);
        image.sC(toRemoveVerticalSeam,toRemoveHorizontalSeam);
        image.outputCarvImage(dataFile.substr(0,dataFile.length()-4));
    }
    return 0;
}
