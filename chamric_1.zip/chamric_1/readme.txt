Chayton Hamric
4322592
cnh47

To run:
	cd into chamric_1 from any terminal then input the following command

	./AlgoP3 [Name of PGM] [Vertical Seam] [Horizontal Seam] 

	then press enter and a file will be created
	and now you have a picture that has the removed amount of pixels that is given in the command